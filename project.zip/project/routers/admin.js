const router=require('express').Router()
const adminSchema=require('../models/admin/adminreg')


router.get('/',(req,res)=>{
   // res.send('admin hello')
   res.render('admin/login.ejs')
})





module.exports=router