const router=require('express').Router()


router.get('/',(req,res)=>{
  //  res.send('frontend hello')
  res.render('index.ejs')
})








module.exports=router